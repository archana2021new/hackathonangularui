import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isInsideShown = true;
  isShown = false;
  firstName: string;
  dob: string;
  lastName: string;
  aadharNum: string;
  phoneNum: string;
  fatherName: string;
  address: string;
  itemMalechecked: boolean;
  itemFemalechecked: boolean;

  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.isInsideShown = true;
    this.httpClient.get('http://localhost:8080/aadhaar/userDetails').subscribe(
      (response) => {
        this.firstName = response['firstName'];
        this.dob = response['dob'];
        this.lastName = response['lastName'];
        this.aadharNum = response['aadhaarNumber'];
        this.phoneNum = response['phoneNumber'];
        this.fatherName = response['fatherName'];
        this.address = response['firstName'];
        if(response['gender'] === 'Female'){
          this.itemFemalechecked = true;
        }
        else{
          this.itemMalechecked = true;
        }
      }
    );
  }

}
