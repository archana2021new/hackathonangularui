import { Component, ChangeDetectorRef, ElementRef, ViewChild } from '@angular/core';
import {Form, FormBuilder} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hackathon-ui';
  isShown = true;
  isInsideShown = false;
  registrationForm = this.fb.group({file: [null]});
  constructor(public fb: FormBuilder, private cd: ChangeDetectorRef, private httpClient: HttpClient, private router: Router) {}
  @ViewChild('fileInput') el: ElementRef;
  imageUrl: any;
  editFile = true;
  removeUpload = false;

  uploadFile(event) {
    const reader = new FileReader(); // HTML5 FileReader API
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);

      // When file uploads set it to file formcontrol
      reader.onload = () => {
        this.imageUrl = reader.result;
        this.registrationForm.patchValue({
          file: reader.result
        });
        this.editFile = false;
        this.removeUpload = true;
      };
      // ChangeDetectorRef since file is loading outside the zone
      this.cd.markForCheck();
      const selectedFile = event.target.files[0];
      const uploadImageData = new FormData();
      uploadImageData.append('imageFile', selectedFile, selectedFile.name);
      this.httpClient.post('http://localhost:8080/aadhaar/upload', uploadImageData, {observe: 'response'}).subscribe((response) => {});
      this.isShown = false;
      this.router.navigateByUrl('/login');
    }
  }
  // Submit Registration Form
  onSubmit() {
    if (!this.registrationForm.valid) {
      alert('Please fill all the required fields');
      return false;
    } else {
      console.log(this.registrationForm.value);
    }
  }
}
